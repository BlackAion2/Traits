# Carnalitas 1.4

This is an update for compatibility with game version 1.3 and will not be compatible with earlier versions or saved games.

## Compatibility

* Updated to work with CK3 version 1.3.

## Tweaks

* A rapist will now piss off all the victim's spouses, friends, and lovers in addition to their close family. If the victim was a concubine, the rapist will piss off their liege.
* Rape is now a valid reason for execution if the rapist gets imprisoned by the victim or one of their lovers.
* Updated Spanish localization. Thanks to Kalvis, our Spanish translator.

## Bug Fixes

* Fixed Demand Manumission important action not appearing.