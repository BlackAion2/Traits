# Carnalitas 1.4.2

Compatible with saved games from Carnalitas version 1.4 and up.

## Localization

* Fixed incorrect encoding on Simplified Chinese files causing them to not be loaded.