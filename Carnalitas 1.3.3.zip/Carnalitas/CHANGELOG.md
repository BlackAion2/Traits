# Carnalitas 1.3.3

Compatible with saved games from version 1.3 and up.

## Compatibility

* Updated for compatibility with CK3 version 1.2.

## Localization

* Added partial Spanish translation thanks to Kalvis.

## Tweaks

* (Modding) Added `carn_slave_cannot_be_freed` flag by request. This character or trait flag blocks a slave from being freed.

## Bug Fixes

* Fixed saved games rarely being corrupted because of a pregnancy being recorded with a futa character as the father.