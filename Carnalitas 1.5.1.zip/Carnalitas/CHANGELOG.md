# Carnalitas 1.5.1

Compatible with saved games from Carnalitas 1.5 and up.

## Bug Fixes

* Fixed carn_add_dick_big_3_effect adding the wrong trait and messing up certain effects in other mods.

## Localization

* Added better Korean localization. Thanks to AKTKNGS for providing it.