# Carnalitas 1.6

NOT COMPATIBLE WITH OLDER SAVED GAMES. Don't do it.

## Compatibility

* Added support for CK3 1.5 and Royal Court.

## Modding

New scripted triggers:
* `carn_possible_pregnancy_after_sex_with_character_trigger`