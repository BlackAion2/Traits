# Carnalitas 1.6

This update makes Carnalitas compatible with Royal Court and 1.5 Fleur-de-Lis.

NOT COMPATIBLE WITH OLDER SAVED GAMES. Don't do it.

## Tweaks

* Made the expanded traits view smaller and more like the vanilla trait grid.

## Bug Fixes

* Fixed cutoff age trigger text not showing properly.
* Fixed some typos; thanks to klorpa for catching them!

## Compatibility

* Updated all files to work with CK3 1.5 and Royal Court as intended.

## Modding

New scripted triggers:
* `carn_possible_pregnancy_after_sex_with_character_trigger`