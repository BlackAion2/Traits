# Carnalitas 1.3.1

Compatible with saved games from version 1.3 and up.

## Bug Fixes

* Fixed breasts clipping through clothes when body part traits are enabled.