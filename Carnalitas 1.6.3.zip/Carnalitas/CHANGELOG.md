# Carnalitas 1.6.3

Bugfix and quality of life release.

Compatible with saved games from Carnalitas 1.6 and up.

# Localization

* Updated French localization, thanks Triskelia!

# Compatibility

* Updated for compatibility with CK3 1.5.1.

# Bug Fixes

* Fixed piety level not being lost properly when you start prostitution.

# Tweaks

* Enslaving a character now only gives dread if executing them would give dread.
* Removed the background and event theme override since bedchamber background is now properly used in vanilla.