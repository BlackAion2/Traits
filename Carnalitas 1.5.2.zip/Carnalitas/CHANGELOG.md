# Carnalitas 1.5.2

Compatible with saved games from Carnalitas 1.5 and up.

## Features

* Re-added same-sex concubinage, because Paradox added it back in.

## Compatibility

* Added support for CK3 1.4 Azure. Nothing really broke, this just tells CK3 the mod is updated for the new version.