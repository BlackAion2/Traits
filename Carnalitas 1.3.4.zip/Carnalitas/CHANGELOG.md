# Carnalitas 1.3.4

Compatible with saved games from version 1.3 and up.

## New Features

### Slavery System

* Modding: Added `carn_any_consort_or_slave_or_slave_owner_is_character_trigger`, `carn_real_father_is_former_slave_or_slave_owner_trigger`

### Miscellaneous

* Added the doctrine parameters `naked_femalepriests_active` and `naked_malepriests_active` which make only female or only male priests naked, respectively. Also checks for `naked_femalepriest_active` and `naked_malepriest_active` for compatibility with the female nudism tenets mod.

## Bug Fixes

* Fixed body part traits not being inherited.
* Fixed slave pregnancies being treated as bastards.